package io.github.mbackschat.a12.dm.interpreter

import io.github.mbackschat.a12.dm.interpreter.eval.Document
import io.github.mbackschat.a12.dm.interpreter.eval.DecimalObjectIdentity
import io.github.mbackschat.a12.dm.interpreter.eval.DocumentPlacementRecord
import io.github.mbackschat.a12.dm.interpreter.eval.newDocument
import io.github.mbackschat.a12.dm.interpreter.eval.parseRangeToIso
import io.github.mbackschat.a12.dm.interpreter.eval.renderDateToFormat
import io.github.mbackschat.a12.dm.interpreter.model.A12_DECIMAL_SCALES
import io.github.mbackschat.a12.dm.interpreter.model.Kind
import io.github.mbackschat.a12.dm.interpreter.model.ModelDef
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.JsonUnquotedLiteral

/**
 * A12's canonical **Document JSON** — the one document shape this project reads and writes at every official
 * boundary (CLAUDE.md "NEVER invent a shape A12 already defines"). The format is the Kernel's, recorded in
 * KERNEL-FINDINGS "The canonical Document JSON and `DocumentPointer` string" from a 30.8.1 source read of
 * `DocumentV2JsonReader` / `DocumentV2JsonWriter` / `DocumentJsonAndXmlDeserializationInfoImpl`:
 *
 * - a **nested object tree mirroring the model** — a non-repeating group is a nested object, a **repeating
 *   group is a JSON array** whose index *is* the repetition, an unfilled row in that array is `{}`, a
 *   present-but-empty group is `{}`, and an **omitted entity is a missing key**;
 * - a field is its value: **native JSON for number and boolean**, a **model-format string** for the date
 *   family, the **S-value** for an enumeration — all read through one stringification
 *   (`value.isNull() ? null : value.asText()`) and then parsed model-driven, because only the model
 *   disambiguates a string from a date;
 * - a **JSON null keeps the field present with no value** (`FieldInstanceV2.ofValue(null)`), which is
 *   [Document.emptyField] here — not an omission;
 * - a value that fails conversion is **not dropped**: the Kernel stores the raw string verbatim and writes
 *   strings back untouched (`[A12K-3638]`), so malformed input is representable in the official shape;
 * - a root-level `id` is a serializer special case, not a model field.
 *
 * **Read is exactly as permissive as A12's reader:** an object at a repeating group is one row at repetition 1,
 * and an array at a *non-repeating* group is rows 1..n — `repetitionsFromJson` never consults repeatability, so
 * an over-repetition (which formal validation exists to report) stays readable. **Write is canonical:** array
 * versus object comes from *declared* repeatability, never from what happens to be populated. The one document
 * state A12's writer has no shape for — a non-repeatable group row above 1 — is refused ([DocumentEncodeError])
 * rather than silently dropped.
 *
 * Read conversion drops unknown or wrong-shaped entities, as A12's serializer does (SPEC-2026-10-10-07;
 * `A12JsonIngressDiffTest`). Syntax, root and scalar-id faults remain fatal, and so does an array holding a
 * non-object at a member of the root or of a row (KF664).
 */
internal object A12DocumentJson {

    /** The serializer's root-level document identity — a string-like key that is deliberately not a model field. */
    const val DOCUMENT_ID_KEY: String = "id"

    private const val TRUE_LITERAL = "true"
    private const val FALSE_LITERAL = "false"

    /** The `{}` an unfilled row of a repeating group is written as. */
    private val EMPTY_ROW = JsonObject(emptyMap())

    /** JSON's own number grammar — the gate for WRITING a stored number back as a native literal. */
    private val JSON_NUMBER = Regex("(-?)(0|[1-9][0-9]*)(?:\\.([0-9]+))?(?:[eE]([-+]?[0-9]+))?")

    /**
     * A12's own CONVERTER grammar — `new BigDecimal(String)`, which `NumberUtil.createBigDecimalIfPossible`
     * calls unchanged. Deliberately **broader** than [JSON_NUMBER]: a leading `+`, a bare `.5`, a trailing `5.`,
     * and leading zeros all parse for it, and A12 therefore normalizes them away. The digit-presence check below
     * rejects what this pattern alone would let through (`""`, `"."`, `"+"`, `"e5"`).
     */
    private val A12_CONVERTER_NUMBER = Regex("([-+]?)([0-9]*)(?:\\.([0-9]*))?(?:[eE]([-+]?[0-9]+))?")

    /**
     * The longest plain form we will materialize. A12 would expand `1e999999999` into a billion characters
     * (`toPlainString` has no ceiling); at a public ingress that is a twelve-character denial of service. The
     * reader charges a number's stored length against the per-field ceiling before it gets here
     * ([plainLengthOrNull]), so this hard bound guards every other caller: beyond it the value stays verbatim,
     * A12's own pass-through shape, which can never produce invalid JSON.
     */
    private const val MAX_PLAIN_LENGTH = DocumentDecodeLimits.HARD_MAX_RAW_CODE_UNITS_PER_FIELD.toLong()

    /** Beyond this exponent no fraction can bring a scale back into 32 bits ([scaleOrNull]). */
    private const val EXPONENT_BOUND = 1L shl 32

    /**
     * [literal] in A12's **plain** number form, or null when it is not a JSON number at all — the WRITE gate.
     *
     * A12 never writes a number in scientific notation: its generator runs with
     * `JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN`, so the emitted text is `BigDecimal.toPlainString()` —
     * the point shifted out, the **scale preserved** (`250.00` stays `250.00`, `1e5` becomes `100000`,
     * `1.2e-3` becomes `0.0012`). Negative zero collapses because `BigDecimal` has none. Matching this is what
     * makes our encode byte-identical to the Kernel's for every legal numeric input, not merely equal in value.
     *
     * Purely lexical on purpose: a decimal *type* would impose a rounding/precision model the transport must
     * not have. Cross-checked against `java.math.BigDecimal.toPlainString` by `A12NumberPlainFormTest`.
     */
    internal fun plainNumberOrNull(literal: String): String? {
        val match = JSON_NUMBER.matchEntire(literal) ?: return null
        val (sign, integerPart, fractionPart, exponentPart) = match.destructured
        return plainForm(sign, integerPart, fractionPart, exponentPart)
    }

    /**
     * [literal] in A12's plain number form when **A12's converter** would parse it, else null — the READ gate.
     * Same output form as [plainNumberOrNull] (one shared lexical conversion, one oracle) over the broader
     * [A12_CONVERTER_NUMBER] grammar, so the values A12 silently normalizes at ingestion — `+5` → `5`,
     * `007` → `7`, `1e5` → `100000`, `-0.0` → `0.0` — normalize here too.
     */
    internal fun canonicalNumberOrNull(literal: String): String? {
        val match = A12_CONVERTER_NUMBER.matchEntire(asciiDigits(literal)) ?: return null
        val (sign, integerPart, fractionPart, exponentPart) = match.destructured
        if (integerPart.isEmpty() && fractionPart.isEmpty()) return null
        return plainForm(sign, integerPart, fractionPart, exponentPart)
    }

    /**
     * The length of the plain form A12 stores for [literal], or null exactly when A12's converter refuses it — the
     * gate [canonicalNumberOrNull] applies, measured without materializing anything, so the reader can charge an
     * exponent's expansion against its ceilings first (`1e999999` is a million code units).
     */
    internal fun plainLengthOrNull(literal: String): Long? {
        val match = A12_CONVERTER_NUMBER.matchEntire(asciiDigits(literal)) ?: return null
        val (sign, integerPart, fractionPart, exponentPart) = match.destructured
        if (integerPart.isEmpty() && fractionPart.isEmpty()) return null
        val scale = scaleOrNull(fractionPart, exponentPart) ?: return null
        return plainLength(unscaledDigits(integerPart, fractionPart), scale, sign == "-")
    }

    /**
     * [literal] with every non-ASCII decimal digit replaced by its ASCII twin. A12's converter is the host decimal
     * constructor, which reads any UTF-16 unit its digit test accepts, so Arabic-Indic `٣.٥` and fullwidth `５`
     * convert to `3.5` and `5` (KF564, `NumberDeclarationIngressDiffTest`). A supplementary-plane digit is two
     * surrogate units, neither a digit, so it stays unconvertible, as it is for the host. The leading-zero keep
     * test still reads the authored text, where only the ASCII `0` counts.
     */
    private fun asciiDigits(literal: String): String {
        if (literal.all { it.code < 0x80 }) return literal
        return buildString(literal.length) {
            for (c in literal) append(if (c.code >= 0x80 && DecimalDigits.isDigit(c)) '0' + DecimalDigits.valueOf(c) else c)
        }
    }

    /**
     * The text A12's reader hands its converter for an UNQUOTED number token, or null when [literal] is not a JSON
     * number. Its mapper parses a token with a point or an exponent into a `BigDecimal` that keeps its signed scale,
     * and `asText()` renders that as `BigDecimal.toString()`: `250.00` stays, `1e3` becomes `1E+3`, `0.0000001`
     * becomes `1E-7`. An integer token renders as its integer, so `-0` becomes `0`. Every kind reads this text; a
     * NUMBER field re-renders it from the value anyway, but a STRING field stores it (KERNEL-FINDINGS KF1,
     * `A12JsonIngressKernelTest`). Purely lexical like [plainForm]; cross-checked against `BigDecimal.toString` by
     * `A12NumberPlainFormTest`.
     *
     * A token whose scale is outside [A12_DECIMAL_SCALES] is no `BigDecimal` to Jackson 3's fast parser — the 32-bit
     * range less `Int.MIN_VALUE`, so `0e2147483648` is refused here although the converter reads the same text quoted —
     * and A12's mapper reads every unquoted token before it looks at the model, so the whole Document is unreadable to
     * it wherever the token stands: this throws a [DocumentInputReasonCode.MALFORMED_JSON] refusal rather than
     * returning a text (KF564, `adapter.laws.NumberExponentEdgeDiffTest`).
     */
    internal fun numberNodeTextOrNull(literal: String): String? {
        val match = JSON_NUMBER.matchEntire(literal) ?: return null
        val (sign, integerPart, fractionPart, exponentPart) = match.destructured
        val digits = unscaledDigits(integerPart, fractionPart)
        val isZero = digits == "0"
        val negative = sign == "-" && !isZero
        if (fractionPart.isEmpty() && exponentPart.isEmpty() && !literal.contains('.')) {
            return if (negative) sign + digits else digits
        }
        val scale = scaleOrNull(fractionPart, exponentPart)?.takeIf { it in A12_DECIMAL_SCALES } ?: throw DocumentInputError.from(listOf(
            MalformedJsonDiagnostic("the number $literal has a scale A12's reader cannot represent"),
        ))
        val adjusted = digits.length - 1 - scale
        // No point-shift ceiling here: the plain branch is reached only at a scale the literal's own length bounds,
        // and the scientific one is as long as the significand, so `1e999999999` stays `1E+999999999`.
        val text = if (scale >= 0 && adjusted >= -6) {
            plainForm("", integerPart, fractionPart, exponentPart) ?: return null
        } else {
            val mantissa = if (digits.length == 1) digits else digits[0] + "." + digits.substring(1)
            mantissa + "E" + (if (adjusted >= 0) "+" else "") + adjusted
        }
        return if (negative) sign + text else text
    }

    /** `BigDecimal.toPlainString()` reproduced lexically from an already-validated significand + exponent. */
    private fun plainForm(sign: String, integerPart: String, fractionPart: String, exponentPart: String): String? {
        val scale = scaleOrNull(fractionPart, exponentPart) ?: return null
        val digits = unscaledDigits(integerPart, fractionPart)
        if (plainLength(digits, scale, sign == "-") > MAX_PLAIN_LENGTH) return null
        val isZero = digits == "0"
        val plain = when {
            // `BigDecimal.toPlainString` short-circuits zero at a negative scale: `0e5` is "0", not "000000".
            scale <= 0 && isZero -> "0"
            scale <= 0 -> digits + "0".repeat((-scale).toInt())
            scale < digits.length -> {
                val point = digits.length - scale.toInt()
                digits.substring(0, point) + "." + digits.substring(point)
            }
            else -> "0." + "0".repeat((scale - digits.length).toInt()) + digits
        }
        // BigDecimal has no negative zero: `-0.0` reads back `0.0`. A leading `+` is never part of its output.
        return if (sign == "-" && !isZero) sign + plain else plain
    }

    /**
     * A leading zero is not part of the UNSCALED value, so `BigDecimal` never renders one: `007` is `7` and
     * `00.50` is `0.50`, and a zero is the single digit `0`. The scale is untouched by the strip — it comes from
     * the fraction and exponent alone. (Caught by the `toPlainString` oracle, not by derivation.)
     */
    private fun unscaledDigits(integerPart: String, fractionPart: String): String =
        (integerPart + fractionPart).trimStart('0').ifEmpty { "0" }

    /**
     * The literal's `BigDecimal` scale, fraction length minus exponent, or null when it has no 32-bit form: the
     * converter refuses exactly that literal, on either side and however the exponent is spelled (`0e2147483648`
     * converts, `0e2147483649` does not; `A12NumberPlainFormTest` against the JDK, KF564 against A12).
     */
    private fun scaleOrNull(fractionPart: String, exponentPart: String): Long? {
        if (exponentPart.isEmpty()) return fractionPart.length.toLong()
        // Refusing an exponent past the bound first also keeps the subtraction from wrapping.
        val exponent = exponentPart.asciiLongOrNull()?.takeIf { it in -EXPONENT_BOUND..EXPONENT_BOUND } ?: return null
        return (fractionPart.length - exponent).takeIf { it in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong() }
    }

    /**
     * The length of `toPlainString()` for [digits] at [scale]. `BigDecimal` short-circuits a zero at a scale
     * of zero or below to `0`, whatever the scale, and has no negative zero.
     */
    private fun plainLength(digits: String, scale: Long, negative: Boolean): Long {
        val isZero = digits == "0"
        val unsigned = when {
            scale <= 0 -> if (isZero) 1 else digits.length - scale
            scale < digits.length -> digits.length + 1L
            else -> 2 + scale
        }
        return if (negative && !isZero) unsigned + 1 else unsigned
    }

    /**
     * The **RUNTIME** rendering of an already-plain stored number — the text A12's `IData` hands every
     * evaluation channel, as against [plainNumberOrNull]'s **serializer** text. A12 renders one stored decimal
     * twice, and the two differ in BOTH directions: a fractional trailing zero beyond [minFractionalDigits] is
     * **stripped** (`250.00` → `250`) and a value with fewer fractional digits than [minFractionalDigits] is
     * **padded** (`250` → `250.00`). IF231; the measurement is KERNEL-FINDINGS "The canonical Document JSON …".
     *
     * Kernel 31.3.1 caps that scale at fifteen digits less the value's [integerDigits], and rounds half up to it
     * (`NumberConversion.determineFractionalDigits`, KERNEL-FINDINGS KF681): a pad stops at the cap
     * (`123456` at a minimum of 10 → `123456.000000000`), and a value with more significant digits is rounded
     * (`1234567890.1234567` → `1234567890.12346`). Within fifteen digits nothing is ever rounded.
     *
     * Purely lexical, for the same reason [plainNumberOrNull] is: routing a transport value through a decimal
     * type would impose the evaluation model's rounding on a rendering that must not have one. Cross-checked
     * against `java.math.BigDecimal` itself by `A12RuntimeNumberFormTest`.
     *
     * [plain] must already be in plain form (a [plainNumberOrNull] / [canonicalNumberOrNull] output): no
     * exponent, no leading `+`, no leading zeros beyond a lone `0`. [integerDigits] is the stored decimal's
     * precision less its scale; the plain form determines it except for a zero written with a positive exponent,
     * whose caller passes the stored one.
     */
    internal fun runtimeNumberForm(plain: String, minFractionalDigits: Int, integerDigits: Int = integerDigitsOf(plain)): String {
        val point = plain.indexOf('.')
        val fractionPart = if (point < 0) "" else plain.substring(point + 1)
        val significantFraction = fractionPart.trimEnd('0')
        // Once no significant fractional digit survives, `stripTrailingZeros().scale()` is <= 0 (`250.00` strips
        // to `2.5E+2`, scale -1; `0.00` to `0`, scale 0) — and `max(<= 0, minFractionalDigits)` is then just
        // minFractionalDigits, which is why the two branches need no signed scale of their own.
        val wanted = if (significantFraction.isEmpty()) minFractionalDigits
        else maxOf(significantFraction.length, minFractionalDigits)
        val scale = minOf(wanted, maxOf(0, MAX_RENDERED_DIGITS - integerDigits))
        if (scale == fractionPart.length) return plain
        val integerPart = if (point < 0) plain else plain.substring(0, point)
        if (scale < significantFraction.length) return roundedHalfUp(integerPart, fractionPart, scale)
        return if (scale == 0) integerPart else integerPart + "." + significantFraction.padEnd(scale, '0')
    }

    /** The digits a runtime rendering keeps at most, `NumberConversion.MAX_ALLOWED_NUMBER_OF_DIGITS`. */
    private const val MAX_RENDERED_DIGITS = 15

    /**
     * A plain number's precision less its scale, as `BigDecimal` counts them: the integer digits of a value of at
     * least one, the negated count of leading fractional zeros below one (`0.5` → 0, `0.0000001` → -6), and for
     * zero one less its written scale (`0` → 1, `0.00` → -1).
     */
    internal fun integerDigitsOf(plain: String): Int {
        val unsigned = plain.removePrefix("-")
        val point = unsigned.indexOf('.')
        val integerPart = if (point < 0) unsigned else unsigned.substring(0, point)
        val fractionPart = if (point < 0) "" else unsigned.substring(point + 1)
        val significantInteger = integerPart.trimStart('0')
        if (significantInteger.isNotEmpty()) return significantInteger.length
        val firstSignificant = fractionPart.indexOfFirst { it != '0' }
        return if (firstSignificant < 0) 1 - fractionPart.length else -firstSignificant
    }

    /**
     * The stored decimal's precision less its scale, read from its written [identity] so that a zero with a positive
     * exponent (`0E+3`, precision 1 and scale -3) counts as A12's converted value does; [plain] answers otherwise.
     */
    private fun integerDigitsOf(identity: DecimalObjectIdentity?, plain: String): Int =
        identity?.let { it.coefficient.removePrefix("-").length - it.scale } ?: integerDigitsOf(plain)

    /** [integerPart]`.`[fractionPart] rounded half away from zero to [scale] fractional digits. */
    private fun roundedHalfUp(integerPart: String, fractionPart: String, scale: Int): String {
        val negative = integerPart.startsWith("-")
        val kept = integerPart.removePrefix("-") + fractionPart.substring(0, scale)
        val digits = if (fractionPart[scale] >= '5') incremented(kept) else kept
        val whole = digits.substring(0, digits.length - scale)
        val magnitude = if (scale == 0) whole else whole + "." + digits.substring(digits.length - scale)
        return if (negative && digits.any { it != '0' }) "-$magnitude" else magnitude
    }

    /** A digit string plus one, carrying into a new leading digit when every digit was a nine. */
    private fun incremented(digits: String): String {
        val result = digits.toCharArray()
        var i = result.size - 1
        while (i >= 0 && result[i] == '9') result[i--] = '0'
        return if (i < 0) "1" + result.concatToString() else result.also { it[i] = it[i] + 1 }.concatToString()
    }

    /**
     * One field cell's stored text in A12's **two renderings** — [stored] is what the serializer writes back,
     * [evaluation] what the runtime hands every evaluation channel. `null` in both slots is the empty cell.
     *
     * They differ for exactly one thing: a **converted NUMBER** whose serializer and runtime renderings disagree
     * (IF231). That Number also retains [numberIdentity], because source-relative computation classification
     * compares its converted coefficient and scale rather than either text. Every other kind — and A12's own
     * pass-through of a value its converter rejects, which stays a `String` that `ValidationData.getValue`
     * returns unchanged — carries one text in both slots.
     */
    private data class CellText(
        val evaluation: String?,
        val stored: String?,
        val numberIdentity: DecimalObjectIdentity? = null,
    ) {
        constructor(one: String?) : this(one, one, null)

        companion object {
            val EMPTY = CellText(null)
        }
    }

    /**
     * The stored text of one field cell as A12's own ingestion leaves it, in both renderings ([CellText]).
     *
     * A12's document is **value-normalizing**: `DocumentV2JsonReader` stringifies the JSON node (`asText()`),
     * `FieldValueConverter` converts that text to `String | Boolean | BigDecimal | Instant | InstantRange`, and
     * every later rendering — the serializer's `toJsonFieldNode`, the runtime's `IData` — is produced from the
     * stored VALUE, never from the authored text. Our cell stores text, so the ingestion normalization has to
     * happen here instead. Per kind, measured by `adapter … A12JsonIngressKernelTest`:
     *
     * - **NUMBER** — [canonicalNumberOrNull] for the serializer text, then [runtimeNumberForm] for the runtime
     *   text; the one case A12 keeps as text is a `leadingZerosAllowed` field's leading-zero value, where
     *   `createBigDecimalIfPossible` returns the original String and both renderings are that String.
     * - **BOOLEAN** — `"true".equalsIgnoreCase` / `"false".equalsIgnoreCase` → the canonical token; **CONFIRM**
     *   accepts only `true` (it has no false, so even a native JSON `false` is a pass-through).
     * - **the DATE family** — nothing to do: the date parse is strict, so every non-canonical spelling
     *   *fails* conversion and is kept verbatim, and every spelling that parses already IS the model format —
     *   except a DATE_RANGE read under a format shared from another declaration ([runtimeRangeText]).
     * - **STRING / Enumeration** — never normalized; A12's converter succeeds with the text itself.
     * - **`""` on any TYPED kind** is `ConversionResult.success(null)` — the empty cell, written back as `null`.
     *   A STRING keeps its `""`.
     *
     * A value the converter cannot parse stays verbatim ([A12K-3638]) and is written back as a JSON string.
     *
     * A number with an exponent can be stored far longer than it is written, so its stored length goes to
     * [chargeStored] before the plain form is built; one kept as text is stored as written and charges nothing.
     */
    private inline fun ModelDef.cellText(path: String, raw: String, chargeStored: (Long) -> Unit): CellText = when (kinds[path]) {
        Kind.NUMBER -> when {
            raw.isEmpty() -> CellText.EMPTY
            else -> {
                if (raw.indexOf('e') >= 0 || raw.indexOf('E') >= 0) {
                    val storedLength = plainLengthOrNull(raw)
                    if (storedLength != null && !(path in leadingZeroNumbers && hasLeadingZeros(raw))) chargeStored(storedLength)
                }
                val converted = canonicalNumberOrNull(raw)
                    ?.takeUnless { path in leadingZeroNumbers && hasLeadingZeros(raw) }
                if (converted == null) CellText(raw)   // A12's pass-through: a String, read back unchanged
                else DecimalObjectIdentity.parse(raw).let { identity ->
                    CellText(runtimeNumberForm(converted, minFractionalDigitsOf(path), integerDigitsOf(identity, converted)),
                        converted, identity)
                }
            }
        }
        Kind.BOOLEAN -> when {
            raw.isEmpty() -> CellText.EMPTY
            raw.equalsIgnoringCaseAsJavaDoes(TRUE_LITERAL) -> CellText(TRUE_LITERAL)
            raw.equalsIgnoringCaseAsJavaDoes(FALSE_LITERAL) -> CellText(FALSE_LITERAL)
            else -> CellText(raw)
        }
        Kind.CONFIRM -> when {
            raw.isEmpty() -> CellText.EMPTY
            raw.equalsIgnoringCaseAsJavaDoes(TRUE_LITERAL) -> CellText(TRUE_LITERAL)
            else -> CellText(raw)
        }
        Kind.DATE, Kind.DATE_TIME, Kind.TIME -> CellText(raw.ifEmpty { null })
        Kind.DATE_RANGE -> if (raw.isEmpty()) CellText.EMPTY else CellText(runtimeRangeText(path, raw), raw)
        Kind.STRING, null -> CellText(raw)
    }

    /**
     * The text a DATE_RANGE value is evaluated as. A12 converts the authored text under the field's DECLARED format
     * into two dates — a missing month or day defaulting to 1 at both ends — and every later reading renders those
     * dates under the RUNTIME format the field may share with others ([ModelDef.rangeConfig]), so a shared yearless
     * format drops a declared year and a shared month format a declared day. Text the declared format cannot convert
     * stays as authored and meets the runtime format's own checks (KERNEL-FINDINGS KF540). The stored text is
     * unchanged.
     */
    private fun ModelDef.runtimeRangeText(path: String, raw: String): String {
        val declared = declaredRangeConfig[path] ?: return raw
        val runtime = rangeConfig.getValue(path)
        if (declared == runtime) return raw
        val (start, end) = parseRangeToIso(raw, declared.first, declared.second, timeZone, baseYear ?: 2000,
            rangeYearInterpretationOf(path), completeEndToLastDay = false) ?: return raw
        val renderedStart = renderDateToFormat(start, runtime.first) ?: return raw
        val renderedEnd = renderDateToFormat(end, runtime.first) ?: return raw
        return renderedStart + runtime.second + renderedEnd
    }

    /**
     * A12's `NumberUtil.containsLeadingZeros` on an already-parseable number: the first digit after an optional
     * sign is `0` and something other than the decimal separator follows it. Note this is lexical, so `0e5`
     * counts as leading-zero-bearing — the Kernel's own behaviour, not a simplification.
     */
    private fun hasLeadingZeros(literal: String): Boolean {
        val afterSign = if (literal[0] == '+' || literal[0] == '-') 1 else 0
        return literal[afterSign] == '0' && literal.length > afterSign + 1 && literal[afterSign + 1] != '.'
    }

    /** One decoded document plus the root `id` the shape carries beside it. */
    internal data class Read(val document: Document, val documentId: String?)

    /**
     * Convert the complete Document JSON text against [model] before building the document, so a fatal
     * input or resource ceiling leaves no partial state. Notification-only nodes are discarded.
     */
    fun read(model: ModelDef, json: String, limits: DocumentDecodeLimits): Read {
        requireWithin(
            actual = json.length.toLong(),
            maximum = limits.maxDocumentCodeUnits.toLong(),
            resource = DocumentInputResource.DOCUMENT_CODE_UNITS,
        ) { null }
        val session = ReadSession(model, limits)
        session.walk(parseRoot(json), path = "", coordinates = emptyList())
        return session.build()
    }

    /**
     * Write [document] as canonical A12 Document JSON: direct fields sorted by name, then direct subgroups
     * sorted by name (the Kernel writer's key order), a declared-repeatable group as an array, everything else
     * as a nested object.
     */
    fun write(model: ModelDef, document: Document, documentId: String?): String {
        val root = WriteNode()
        document.placementsSnapshot().forEach { root.place(it) }
        if (documentId != null) root.fields[DOCUMENT_ID_KEY] = documentId
        return A12_JSON.encodeToString(
            JsonObject.serializer(),
            root.toJson(model, path = "", coordinates = emptyList()),
        )
    }

    private fun parseRoot(json: String): JsonObject {
        val element = try {
            parseA12Json(json)
        } catch (failure: Exception) {
            throw DocumentInputError.from(listOf(MalformedJsonDiagnostic(failure.message ?: "unparseable JSON")))
        }
        return element as? JsonObject
            ?: throw DocumentInputError.from(
                listOf(MalformedJsonDiagnostic("the document root must be a JSON object but was ${element.nodeType()}")),
            )
    }

    // ---- read -----------------------------------------------------------------------------------------

    private class ReadSession(private val model: ModelDef, private val limits: DocumentDecodeLimits) {
        /** Encounter-ordered pending placements — applied in JSON document order, mirroring A12's read order. */
        private val pending = mutableListOf<Pending>()
        private var groupRows = 0L
        private var fieldCells = 0L
        private var totalRawCodeUnits = 0L
        private var documentId: String? = null

        /**
         * Reads one object A12 reads as a group — the root or a row — whose array members A12 requires to hold only
         * objects. It checks that before it asks the model what the member is, so a known group, a field, an unknown
         * key and the root `id` refuse the Document alike, while an object the model does not read as a group is never
         * walked and so never checked (kernel 31.1.1, KERNEL-FINDINGS KF664, `adapter.laws.A12JsonIngressDiffTest`).
         */
        fun walk(node: JsonObject, path: String, coordinates: List<Int>) {
            for ((name, child) in node) {
                val childPath = "$path/$name"
                if (child is JsonArray) requireObjectElements(childPath, child)
                val kind = ModelAddressValidation.entityKind(model, childPath)
                if (kind == null && path.isEmpty() && name == DOCUMENT_ID_KEY) {
                    readDocumentId(child)
                    continue
                }
                val ownCoordinates = coordinates + 1
                requireWithin(
                    actual = childPath.length.toLong(),
                    maximum = limits.maxPathCodeUnits.toLong(),
                    resource = DocumentInputResource.PATH_CODE_UNITS,
                ) { A12PointerFormat.format(childPath, ownCoordinates) }
                requireWithin(
                    actual = ownCoordinates.size.toLong(),
                    maximum = limits.maxModelNestingDepth.toLong(),
                    resource = DocumentInputResource.MODEL_NESTING_DEPTH,
                ) { A12PointerFormat.format(childPath, ownCoordinates) }
                when (kind) {
                    ModelEntityKind.FIELD -> readCell(childPath, ownCoordinates, child)
                    ModelEntityKind.GROUP -> readGroup(childPath, coordinates, child)
                    null -> requireReadableNumbers(child)
                }
            }
        }

        fun build(): Read {
            val document = model.newDocument()
            for (placement in pending) {
                val coordinates = placement.coordinates.toIntArray()
                val text = placement.text
                when {
                    placement.isGroup -> document.group(placement.path, *coordinates)
                    text.stored == null -> document.emptyField(placement.path, *coordinates)
                    else -> document.renderedField(
                        path = placement.path,
                        evaluationValue = text.evaluation!!,
                        storedValue = text.stored,
                        numberIdentity = text.numberIdentity,
                        reps = coordinates,
                    )
                }
            }
            return Read(document, documentId)
        }

        // Every pointer here is built LAZILY: a canonical pointer string per cell would allocate once per
        // field of every document just to hand a ceiling check a locator it almost never uses.
        private fun readCell(path: String, coordinates: List<Int>, node: JsonElement) {
            val pointer = { A12PointerFormat.format(path, coordinates) }
            when {
                node === JsonNull -> {
                    countCell(pointer)
                    pending += Pending(path, coordinates, CellText.EMPTY, isGroup = false)
                }
                node is JsonPrimitive -> {
                    countCell(pointer)
                    // The ceilings measure the AUTHORED text — that is the input a caller controls, and it is
                    // charged before any normalization can shorten or lengthen it.
                    val raw = node.content
                    requireWithin(
                        actual = raw.length.toLong(),
                        maximum = limits.maxRawCodeUnitsPerField.toLong(),
                        resource = DocumentInputResource.RAW_CODE_UNITS_PER_FIELD,
                        pointer = pointer,
                    )
                    totalRawCodeUnits += raw.length
                    requireWithin(
                        actual = totalRawCodeUnits,
                        maximum = limits.maxTotalRawCodeUnits.toLong(),
                        resource = DocumentInputResource.TOTAL_RAW_CODE_UNITS,
                        pointer = pointer,
                    )
                    // A12 reads a value as its node's text, so an unquoted number arrives in its BigDecimal or
                    // integer rendering rather than as typed; a quoted one is kept as typed.
                    val text = if (node.isString) raw else numberNodeTextOrNull(raw) ?: raw
                    val cell = model.cellText(path, text) { stored -> chargeExpansion(stored, raw.length, pointer) }
                    pending += Pending(path, coordinates, cell, isGroup = false)
                }
                else -> requireReadableNumbers(node)
            }
        }

        /**
         * The ceilings bound what the Document holds, and A12 holds a number in its plain form, so the growth from
         * the authored literal to that form is charged too: to the per-field ceiling and to the total.
         */
        private fun chargeExpansion(stored: Long, authored: Int, pointer: () -> String) {
            if (stored <= authored) return
            requireWithin(stored, limits.maxRawCodeUnitsPerField.toLong(), DocumentInputResource.RAW_CODE_UNITS_PER_FIELD, pointer)
            totalRawCodeUnits += stored - authored
            requireWithin(totalRawCodeUnits, limits.maxTotalRawCodeUnits.toLong(), DocumentInputResource.TOTAL_RAW_CODE_UNITS, pointer)
        }

        /**
         * A12's mapper reads every unquoted number in the text before it looks at the model, so one it cannot
         * represent is fatal even where the model reads nothing: an unknown key, a misplaced node, and anything
         * beneath them ([numberNodeTextOrNull] refuses it). Iterative, so a deep discarded subtree cannot exhaust
         * the stack.
         */
        private fun requireReadableNumbers(node: JsonElement) {
            val pending = ArrayDeque<JsonElement>().apply { add(node) }
            while (pending.isNotEmpty()) {
                when (val next = pending.removeLast()) {
                    is JsonObject -> pending.addAll(next.values)
                    is JsonArray -> pending.addAll(next)
                    is JsonPrimitive -> if (next !== JsonNull && !next.isString) numberNodeTextOrNull(next.content)
                }
            }
        }

        private fun requireObjectElements(path: String, array: JsonArray) {
            val offending = array.indexOfFirst { it !is JsonObject }
            if (offending < 0) return
            throw DocumentInputError.from(listOf(MalformedJsonDiagnostic(
                "the array at $path holds ${array[offending].nodeType().spelled()} at position ${offending + 1}, " +
                    "and A12's reader admits only objects in an array",
            )))
        }

        /** An array here holds only objects: [walk] refused any other element before dispatching to this. */
        private fun readGroup(path: String, parentCoordinates: List<Int>, node: JsonElement) {
            when (node) {
                is JsonObject -> readRow(path, parentCoordinates + 1, node)
                is JsonArray -> node.forEachIndexed { index, element ->
                    readRow(path, parentCoordinates + (index + 1), element as JsonObject)
                }
                else -> requireReadableNumbers(node)
            }
        }

        private fun readRow(path: String, coordinates: List<Int>, node: JsonObject) {
            groupRows++
            requireWithin(
                actual = groupRows,
                maximum = limits.maxGroupPlacements.toLong(),
                resource = DocumentInputResource.GROUP_PLACEMENTS,
            ) { A12PointerFormat.format(path, coordinates) }
            pending += Pending(path, coordinates, CellText.EMPTY, isGroup = true)
            walk(node, path, coordinates)
        }

        /**
         * A12's scalar-id branch accepts text and, without Java assertions, numbers. Containers follow group
         * conversion and are discarded here; Boolean/null scalar ids are fatal (`A12JsonIngressDiffTest`). A numeric id
         * is its node's text like any unquoted number, so `1e3` reads `1E+3` (`DocumentJsonAndXmlDeserializationInfoImpl`
         * takes `value.asText()` on the id branch as on a field's).
         */
        private fun readDocumentId(node: JsonElement) {
            if (node is JsonObject || node is JsonArray) return requireReadableNumbers(node)
            if (node is JsonPrimitive && node !== JsonNull && node.isString) {
                documentId = node.content
                return
            }
            val numberText = if (node is JsonPrimitive && node !== JsonNull) numberNodeTextOrNull(node.content) else null
            if (numberText != null) {
                documentId = numberText
                return
            }
            throw DocumentInputError.from(listOf(InvalidDocumentIdDiagnostic(node.nodeType())))
        }

        private fun countCell(pointer: () -> String?) {
            fieldCells++
            requireWithin(
                actual = fieldCells,
                maximum = limits.maxFieldPlacements.toLong(),
                resource = DocumentInputResource.FIELD_PLACEMENTS,
                pointer = pointer,
            )
        }
    }

    private data class Pending(
        val path: String,
        val coordinates: List<Int>,
        val text: CellText,
        val isGroup: Boolean,
    )

    /** [pointer] is evaluated only when the ceiling is actually exceeded. */
    private inline fun requireWithin(
        actual: Long,
        maximum: Long,
        resource: DocumentInputResource,
        pointer: () -> String?,
    ) {
        if (actual > maximum) {
            throw DocumentInputError.from(
                listOf(ResourceLimitExceededDiagnostic(resource, maximum, actual, pointer())),
            )
        }
    }

    // ---- write ----------------------------------------------------------------------------------------

    /** One group instance being written: its direct field cells (a `null` value is a present-empty cell). */
    private class WriteNode {
        val fields = LinkedHashMap<String, String?>()
        val subgroups = LinkedHashMap<String, MutableMap<Int, WriteNode>>()

        fun place(record: DocumentPlacementRecord) {
            val parts = record.path.trim('/').split('/')
            check(parts.size == record.reps.size) {
                "placement '${record.path}' carries ${record.reps.size} coordinates for ${parts.size} path parts"
            }
            val groupDepth = if (record.isGroup) parts.size else parts.size - 1
            var node = this
            for (level in 0 until groupDepth) {
                node = node.child(parts[level], record.reps[level])
            }
            if (record.isGroup) return
            check(record.reps.last() == 1) {
                "field cell '${record.path}' carries repetition ${record.reps.last()}; a field has no repetition axis"
            }
            node.fields[parts.last()] = record.raw
        }

        fun toJson(model: ModelDef, path: String, coordinates: List<Int>): JsonObject {
            val out = LinkedHashMap<String, JsonElement>()
            for (name in fields.keys.sorted()) {
                out[name] = fieldToJson(model, "$path/$name", fields[name])
            }
            for (name in subgroups.keys.sorted()) {
                val childPath = "$path/$name"
                val rows = subgroups.getValue(name)
                out[name] = if (childPath in model.repeatable) {
                    JsonArray(
                        (1..rows.keys.max()).map { repetition ->
                            rows[repetition]?.toJson(model, childPath, coordinates + repetition) ?: EMPTY_ROW
                        },
                    )
                } else {
                    rows.keys.filter { it != 1 }.minOrNull()?.let { excess ->
                        throw DocumentEncodeError.nonRepeatableRow(
                            modelPath = childPath,
                            pointer = A12PointerFormat.format(childPath, coordinates + excess),
                        )
                    }
                    rows.getValue(1).toJson(model, childPath, coordinates + 1)
                }
            }
            return JsonObject(out)
        }

        private fun child(name: String, repetition: Int): WriteNode =
            subgroups.getOrPut(name) { LinkedHashMap() }.getOrPut(repetition) { WriteNode() }
    }

    /**
     * One field cell as A12 writes it: **native JSON** where the stored text *is* the canonical literal for the
     * declared kind, otherwise the text as a JSON string — the Kernel's own pass-through for a value it could
     * not convert. A cell with no stored text is `null`, which reads back present-and-valueless.
     */
    @OptIn(ExperimentalSerializationApi::class)
    private fun fieldToJson(model: ModelDef, path: String, raw: String?): JsonElement {
        if (raw == null) return JsonNull
        return when (model.kinds[path]) {
            // A12 emits the PLAIN form, never scientific — see [plainNumberOrNull].
            Kind.NUMBER -> plainNumberOrNull(raw)?.let { JsonUnquotedLiteral(it) } ?: JsonPrimitive(raw)
            Kind.BOOLEAN ->
                if (raw == TRUE_LITERAL || raw == FALSE_LITERAL) JsonUnquotedLiteral(raw) else JsonPrimitive(raw)
            // A CONFIRM has no false — `parseConfirm` converts only `true`, so even a native JSON `false` is a
            // value A12 could not convert and writes back as the string `"false"`.
            Kind.CONFIRM -> if (raw == TRUE_LITERAL) JsonUnquotedLiteral(raw) else JsonPrimitive(raw)
            // The date family and enumerations are model-format strings; `null` is the root `id` pseudo-field.
            Kind.STRING, Kind.DATE, Kind.DATE_TIME, Kind.TIME, Kind.DATE_RANGE, null -> JsonPrimitive(raw)
        }
    }
}

private fun JsonElement.nodeType(): DocumentJsonNodeType = when {
    this === JsonNull -> DocumentJsonNodeType.NULL
    this is JsonObject -> DocumentJsonNodeType.OBJECT
    this is JsonArray -> DocumentJsonNodeType.ARRAY
    else -> DocumentJsonNodeType.VALUE
}

/** The node type as the diagnostic prose names it, spelled here so shared code runs no platform case table. */
private fun DocumentJsonNodeType.spelled(): String = when (this) {
    DocumentJsonNodeType.OBJECT -> "an object"
    DocumentJsonNodeType.ARRAY -> "an array"
    DocumentJsonNodeType.VALUE -> "a value"
    DocumentJsonNodeType.NULL -> "a null"
}

private data class MalformedJsonDiagnostic(private val detail: String) : DocumentInputDiagnostic {
    override val reasonCode = DocumentInputReasonCode.MALFORMED_JSON
    override val message = "the Document JSON could not be read: $detail"
}

private data class InvalidDocumentIdDiagnostic(
    override val nodeType: DocumentJsonNodeType,
) : DocumentInputDiagnostic {
    override val reasonCode = DocumentInputReasonCode.INVALID_DOCUMENT_ID
    override val message =
        "the root '${A12DocumentJson.DOCUMENT_ID_KEY}' carries ${nodeType.name.asciiLowercase()}; it must be a string"
}

private data class ResourceLimitExceededDiagnostic(
    override val resource: DocumentInputResource,
    override val maximum: Long,
    override val actual: Long,
    override val pointer: String?,
) : DocumentInputDiagnostic {
    override val reasonCode = DocumentInputReasonCode.RESOURCE_LIMIT_EXCEEDED
    override val message =
        "Document decoding exceeded ${resource.name.asciiLowercase()} limit $maximum (actual $actual)"
}
